import WeatherBannerApp2 from './components/WeatherBannerApp2.tsx'
import './App.css'

function App() {



  return (
    <>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        <WeatherBannerApp2 />
      </div>
    </>
  )
}

export default App
